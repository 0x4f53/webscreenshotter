# screenshot stitcher

A utility that takes a stitched screenshot of a webpage along with individual ones, at any resolution
